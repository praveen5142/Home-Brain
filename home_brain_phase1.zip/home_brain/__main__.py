"""
Home Brain — Main Entry Point

Two modes:
  python -m home_brain run          → extract clips for yesterday (production)
  python -m home_brain test         → record 60s right now + extract clips (dev)
  python -m home_brain list [date]  → list clips for a date
  python -m home_brain schedule     → run as a daily cron-style scheduler

Usage:
  cd home_brain_project/
  python -m home_brain run
  python -m home_brain test
  python -m home_brain list 2025-12-01
"""
import sys
import os
from datetime import date, datetime, timedelta

# Allow running as: python -m home_brain
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from home_brain.container import build_container
from home_brain.shared.logger import get_logger

logger = get_logger("home_brain.main")


def cmd_run(target_date: date | None = None) -> None:
    """Run extraction for a specific date (default: yesterday)."""
    if target_date is None:
        target_date = date.today() - timedelta(days=1)

    logger.info(f"=== Home Brain | Daily Extraction | {target_date} ===")
    container = build_container()
    clips = container.ingestion_service.run_daily_extraction(target_date)

    print(f"\n✅ Extracted {len(clips)} clips for {target_date}")
    total_mb = sum((c.size_bytes or 0) for c in clips) / 1024 / 1024
    total_s = sum(c.duration_seconds for c in clips)
    print(f"   Total activity: {total_s:.0f}s | Disk used: {total_mb:.1f} MB")
    print(f"\n   Clips:")
    for clip in clips:
        print(f"   [{clip.recorded_at.strftime('%H:%M:%S')}] "
              f"{clip.duration_seconds:.0f}s | "
              f"{(clip.size_bytes or 0)/1024:.0f} KB | "
              f"{clip.file_path.name}")


def cmd_test() -> None:
    """
    Dev mode: record 60s from the live stream right now, then extract clips.
    Set RECORD_DURATION_S=60 in .env for this to work quickly.
    """
    os.environ["RECORD_DURATION_S"] = "60"
    logger.info("=== TEST MODE: Recording 60s from live stream ===")
    cmd_run(target_date=date.today())


def cmd_list(target_date: date | None = None) -> None:
    """List clips stored for a given date."""
    if target_date is None:
        target_date = date.today() - timedelta(days=1)

    container = build_container()
    clips = container.clip_storage.find_by_date(target_date)

    if not clips:
        print(f"No clips found for {target_date}")
        return

    print(f"\n📹 Clips for {target_date} ({len(clips)} total):\n")
    for clip in clips:
        size = f"{clip.size_bytes/1024:.0f}KB" if clip.size_bytes else "unknown"
        print(
            f"  [{clip.recorded_at.strftime('%H:%M:%S')}] "
            f"{clip.duration_seconds:.0f}s | {size} | "
            f"status={clip.status.value} | {clip.file_path.name}"
        )


def cmd_schedule() -> None:
    """
    Runs as a daily scheduler.
    Triggers extraction every day at 06:00 AM for the previous day.
    For production use, prefer system cron:
      0 6 * * * cd /path/to/project && python -m home_brain run
    """
    import time
    logger.info("Scheduler started. Will run extraction daily at 06:00.")

    while True:
        now = datetime.now()
        # Next 06:00
        next_run = now.replace(hour=6, minute=0, second=0, microsecond=0)
        if next_run <= now:
            next_run += timedelta(days=1)

        wait_seconds = (next_run - now).total_seconds()
        logger.info(f"Next extraction at {next_run} (in {wait_seconds/3600:.1f}h)")
        time.sleep(wait_seconds)

        try:
            cmd_run()
        except Exception as e:
            logger.error(f"Scheduled extraction failed: {e}")


def main():
    args = sys.argv[1:]
    command = args[0] if args else "run"

    if command == "run":
        target = date.fromisoformat(args[1]) if len(args) > 1 else None
        cmd_run(target)

    elif command == "test":
        cmd_test()

    elif command == "list":
        target = date.fromisoformat(args[1]) if len(args) > 1 else None
        cmd_list(target)

    elif command == "schedule":
        cmd_schedule()

    else:
        print(f"Unknown command: {command}")
        print("Usage: python -m home_brain [run|test|list|schedule] [date]")
        sys.exit(1)


if __name__ == "__main__":
    main()
