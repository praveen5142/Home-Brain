# 🏠 Home Brain — Phase 1: Surveillance

RTSP → Motion Detection → Clip Extraction → SQLite

## Prerequisites

```bash
# 1. Install ffmpeg (system dependency)
sudo apt install ffmpeg          # Ubuntu/Debian
brew install ffmpeg              # macOS

# 2. Install Python dependencies
pip install -r requirements.txt

# 3. Configure
cp .env.example .env
# Edit .env with your camera IP and password
```

## Find Your Camera's IP

1. Open your router admin page (usually `192.168.1.1`)
2. Find **DHCP Client List** or **Connected Devices**
3. Look for a device named "IPCAM" or similar
4. **Set a static IP** for it (important! IP must not change)

## Test the RTSP connection first

```bash
# Replace with your camera's IP and credentials
ffplay "rtsp://admin:YOUR_PASS@192.168.1.XXX:554/cam/realmonitor?channel=1&subtype=1"
```

You should see live video. If not, check IP/credentials.

## Run

```bash
# Test mode: records 60s from live stream, extracts clips
python -m home_brain test

# Production: extract clips for yesterday's recording
python -m home_brain run

# Extract for a specific date
python -m home_brain run 2025-12-01

# List clips in database
python -m home_brain list
python -m home_brain list 2025-12-01

# Run as daily scheduler (or use cron — preferred)
python -m home_brain schedule
```

## Cron Setup (recommended for always-on laptop)

```bash
crontab -e
# Add this line — runs at 6:00 AM daily:
0 6 * * * cd /path/to/home_brain_project && python -m home_brain run >> ./logs/home_brain.log 2>&1
```

## Project Structure

```
home_brain/
├── shared/
│   ├── config.py          ← All env vars, zero hardcoding
│   └── logger.py
├── surveillance/
│   ├── domain/
│   │   ├── entities/
│   │   │   └── clip.py    ← Clip, MotionWindow (pure domain)
│   │   ├── ports/
│   │   │   └── ports.py   ← Interfaces (contracts)
│   │   └── services/
│   │       └── stream_ingestion_service.py  ← Business logic
│   └── adapters/
│       ├── ffmpeg_adapter.py           ← RTSP + motion detection
│       └── sqlite_clip_storage_adapter.py  ← Persistence
├── container.py           ← Dependency injection / wiring
├── __main__.py            ← CLI entry point
├── .env.example           ← Config template
└── requirements.txt
```

## Phase 2 (coming next)
- Claude Vision → mood analysis per clip
- Whisper → audio transcription
- Telegram Bot → daily summary notification
- Backblaze B2 → 30-day archive
