"""
Composition Root — container.py

This is the ONLY place that knows about all adapters.
Wires ports → adapters → services.

In Hexagonal Architecture, the composition root lives outside all domains.
It's the "main" that plugs everything together.

No domain imports an adapter. All dependencies flow inward.
"""
from pathlib import Path

from .shared.config import AppConfig
from .surveillance.adapters.ffmpeg_adapter import (
    FfmpegMotionDetectionAdapter,
    FfmpegStreamRecorderAdapter,
)
from .surveillance.adapters.sqlite_clip_storage_adapter import SQLiteClipStorageAdapter
from .surveillance.domain.services.stream_ingestion_service import StreamIngestionService


class Container:
    """
    Manual DI container.
    No frameworks — keeps it simple and transparent.
    Each property is lazily initialized and cached.
    """

    def __init__(self, config: AppConfig):
        self._config = config
        self._recorder = None
        self._motion_detector = None
        self._clip_storage = None
        self._ingestion_service = None

    @property
    def recorder(self) -> FfmpegStreamRecorderAdapter:
        if self._recorder is None:
            self._recorder = FfmpegStreamRecorderAdapter()
        return self._recorder

    @property
    def motion_detector(self) -> FfmpegMotionDetectionAdapter:
        if self._motion_detector is None:
            self._motion_detector = FfmpegMotionDetectionAdapter()
        return self._motion_detector

    @property
    def clip_storage(self) -> SQLiteClipStorageAdapter:
        if self._clip_storage is None:
            self._clip_storage = SQLiteClipStorageAdapter(
                db_path=self._config.storage.db_path
            )
        return self._clip_storage

    @property
    def ingestion_service(self) -> StreamIngestionService:
        if self._ingestion_service is None:
            self._ingestion_service = StreamIngestionService(
                config=self._config,
                recorder=self.recorder,
                motion_detector=self.motion_detector,
                clip_storage=self.clip_storage,
            )
        return self._ingestion_service


def build_container() -> Container:
    config = AppConfig.from_env()
    return Container(config=config)
